import argparse
import logging
from pubmed_papers.fetcher import fetch_pubmed_ids, fetch_paper_details
from pubmed_papers.parser import parse_paper_xml
from pubmed_papers.writer import save_to_csv, print_results

def main():
    parser = argparse.ArgumentParser(description="Fetch PubMed papers with non-academic authors.")
    parser.add_argument("query", help="PubMed query string")
    parser.add_argument("-f", "--file", help="Output CSV filename")
    parser.add_argument("-d", "--debug", action="store_true", help="Enable debug logs")
    args = parser.parse_args()

    if args.debug:
        logging.basicConfig(level=logging.DEBUG)

    logging.info("Fetching PMIDs...")
    pmids = fetch_pubmed_ids(args.query)

    if not pmids:
        print("No papers found.")
        return

    logging.info(f"Found {len(pmids)} papers. Fetching details...")
    xml_data = fetch_paper_details(pmids)
    results = parse_paper_xml(xml_data)

    if args.file:
        save_to_csv(results, args.file)
        print(f"Saved to {args.file}")
    else:
        print_results(results)

if __name__ == "__main__":
    main()
