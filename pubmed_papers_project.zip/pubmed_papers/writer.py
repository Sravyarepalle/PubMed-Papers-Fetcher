import pandas as pd
from typing import List, Dict

def save_to_csv(results: List[Dict], filename: str) -> None:
    df = pd.DataFrame(results)
    df.to_csv(filename, index=False)

def print_results(results: List[Dict]) -> None:
    for r in results:
        print(r)
