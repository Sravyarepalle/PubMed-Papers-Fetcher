import xml.etree.ElementTree as ET
from typing import List, Dict

COMPANY_KEYWORDS = ["pharma", "biotech", "inc", "ltd", "gmbh", "corp", "therapeutics"]

def is_company_affiliation(affiliation: str) -> bool:
    affiliation_lower = affiliation.lower()
    return any(k in affiliation_lower for k in COMPANY_KEYWORDS) and not any(x in affiliation_lower for x in ["university", "college", "institute", "hospital", "school"])

def parse_paper_xml(xml_data: str) -> List[Dict]:
    root = ET.fromstring(xml_data)
    papers = []
    for article in root.findall(".//PubmedArticle"):
        pmid = article.findtext(".//PMID")
        title = article.findtext(".//ArticleTitle")
        pub_date_elem = article.find(".//PubDate")
        pub_date = pub_date_elem.findtext("Year") if pub_date_elem is not None else "Unknown"

        authors, affiliations, emails = [], [], []

        for author in article.findall(".//Author"):
            last = author.findtext("LastName") or ""
            fore = author.findtext("ForeName") or ""
            full_name = f"{fore} {last}".strip()
            for aff in author.findall(".//AffiliationInfo/Affiliation"):
                aff_text = aff.text or ""
                if is_company_affiliation(aff_text):
                    authors.append(full_name)
                    affiliations.append(aff_text)
                    if "@" in aff_text:
                        emails.append(aff_text.split()[-1])

        if authors:
            papers.append({
                "PubmedID": pmid,
                "Title": title,
                "Publication Date": pub_date,
                "Non-academicAuthor(s)": "; ".join(set(authors)),
                "CompanyAffiliation(s)": "; ".join(set(affiliations)),
                "Corresponding Author Email": "; ".join(set(emails)),
            })
    return papers
