# PubMed Papers Fetcher

## Description
CLI tool to fetch research papers from PubMed based on a query. Filters papers with at least one author affiliated with a pharmaceutical or biotech company.

## Installation
```bash
poetry install
```

## Usage
```bash
poetry run get-papers-list "cancer immunotherapy" -f results.csv --debug
```

## Features
- Fetches PubMed data via API
- Filters for non-academic affiliations
- CSV or console output
